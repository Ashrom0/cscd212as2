public interface Observer {
	public void update(int hobbits, int elves, int dwarfs, int men);

}
