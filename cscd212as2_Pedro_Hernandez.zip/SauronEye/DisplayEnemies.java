public interface DisplayEnemies {
	public void display();
}
